//
//  SecuredCallsVoiceSDK.h
//  SecuredCallsVoiceSDK
//
//  Created by Amandeep Kaile on 19/7/2024.
//

#import <Foundation/Foundation.h>

//! Project version number for SecuredCallsVoiceSDK.
FOUNDATION_EXPORT double SecuredCallsVoiceSDKVersionNumber;

//! Project version string for SecuredCallsVoiceSDK.
FOUNDATION_EXPORT const unsigned char SecuredCallsVoiceSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SecuredCallsVoiceSDK/PublicHeader.h>


